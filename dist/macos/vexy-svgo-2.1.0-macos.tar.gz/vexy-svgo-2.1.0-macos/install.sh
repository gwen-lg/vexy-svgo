#!/bin/bash
# Vexy SVGO macOS installer

echo "Installing vexy-svgo to /usr/local/bin..."
sudo mkdir -p /usr/local/bin
sudo cp vexy-svgo /usr/local/bin/
sudo chmod 755 /usr/local/bin/vexy-svgo

echo "Installation complete!"
echo "You can now use 'vexy-svgo' from Terminal."