Vexy SVGO v2.1.0 for macOS
=============================

Quick Install:
  ./install.sh

Manual Install:
  Copy vexy-svgo to a directory in your PATH

Usage:
  vexy-svgo [OPTIONS] <INPUT>

For more information:
  https://github.com/vexyart/vexy-svgo